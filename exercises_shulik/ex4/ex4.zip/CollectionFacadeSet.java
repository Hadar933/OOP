/**
 * The class wraps underlying Collection and serves to both simplify its API and give it a common type
 * with the implemented SimpleHashSet.
 */
public class CollectionFacadeSet implements SimpleSet{
    /**
     * An instance of the collection the facade instance wraps.
     */
    protected java.util.Collection<java.lang.String> collection;

    /**
     * Creates a new facade wrapping the specified collection.
     * @param collection - The Collection to wrap.
     */
    public CollectionFacadeSet(java.util.Collection<java.lang.String> collection) {
        this.collection = collection; //might contain doubles.
    }

    /**
     * This method adds al items
     * @param newValue New value to add to the set
     * @return
     */
    public boolean add(java.lang.String newValue){
        if(!this.collection.contains(newValue)) { //checks to prevent adding the same value twice.
            return this.collection.add(newValue);
        }
        return false;
    }

    /**
     * Look for a specified value in the set.
     * @param searchVal - Value to search for.
     * @return - True if searchVal is found in the set, False otherwise.
     */
    public boolean contains(java.lang.String searchVal){
        return this.collection.contains(searchVal);
    }

    /**
     * Remove the input element from the set.
     * @param toDelete - Value to delete.
     * @return - True if toDelete is found and deleted.
     */
    public boolean delete(java.lang.String toDelete){
        return this.collection.remove(toDelete);
    }

    /**
     * @return - The number of elements currently in the set.
     */
    public int size(){
        return this.collection.size();
    }

}
