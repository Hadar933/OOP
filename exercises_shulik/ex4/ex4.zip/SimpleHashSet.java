/**
 * A superclass for implementations of hash-sets implementing the simpleSet interface.
 */
public abstract class SimpleHashSet implements SimpleSet{

    protected static final int INCREASETABLE = 1;

    protected static final int DECREASETABLE = -1;

    /**
     * Describes the higher load factor of a newly created has set.
     */
    protected static final float DEFAULT_HIGHER_CAPACITY = 0.75f;

    /**
     * Describes the lower load factor of a newly created hash set.
     */
    protected static final float DEFAULT_LOWER_CAPACITY = 0.25f;

    /**
     * Describes the capacity of a newly created hash set.
     */
    protected static final int INITIAL_CAPACITY = 16;

    /**
     * Describes the upper load factor of the hash set.
     */
    protected float upperLoad;

    /**
     * Describes the lower load factor of the hash set.
     */
    protected float lowerLoad;

    /**
     * Describes the capacity of the newly created set.
     */
    protected int tableCapacity;

    /**
     * Describes the size of the table - amount of items in the table.
     */
    protected int tableSize;

    /**
     * Constructs a new hash set with DEFAULT_LOWER_CAPACITY and DEFAULT_HIGHER_CAPACITY
     */
    protected SimpleHashSet() {
        this.upperLoad = DEFAULT_HIGHER_CAPACITY;
        this.lowerLoad = DEFAULT_LOWER_CAPACITY;
        this.tableCapacity = INITIAL_CAPACITY;
        this.tableSize = 0;
    }

    /**
     * Constructs a new hash set with capacity INITIAL_CAPACITY.
     * @param upperLoadFactor - th upper load factor before rehashing.
     * @param lowerLoadFactor - the lower load factor before rehashing.
     */
    protected SimpleHashSet(float upperLoadFactor, float lowerLoadFactor) {
        this.upperLoad = upperLoadFactor;
        this.lowerLoad = lowerLoadFactor;
        this.tableCapacity = INITIAL_CAPACITY;
        this.tableSize = 0;
    }

    /**
     * An abstract method has to be implemented by subclass.
     * @return - The current capacity(number of cells) of the table.
     */
    public abstract int capacity();

    /**
     * Clamps hashing indices to fit within the current table capacity.
     * @param index - the index before clamping.
     * @return - an index properly clamped.
     */
    protected abstract int clamp(int index);

    /**
     * @return - the lower load factor of the table.
     */
    protected float getLowerLoadFactor(){
        return this.lowerLoad;
    }

    /**
     * @return - the upper load factor of the table.
     */
    protected float getUpperLoadFactor(){
        return this.upperLoad;
    }

    /**
     * @param changeFactor - Could either be 1 or -1, checks the load factor after the change.
     * @return - INCREASETABLE(1) - if the table should be increased, DECREASETABLE(-1) if the table should
     * be decreased and 0 if the load factor is in the given limits.
     */
    protected int checkLoadFactor(int changeFactor ) {
        double futureLoadFactor = (double)(this.size() + changeFactor) / this.capacity();
        if (futureLoadFactor > this.getUpperLoadFactor()) {
            return INCREASETABLE; // the load factor is over the upper load factor, bigger table is needed.
        } else if (futureLoadFactor < this.getLowerLoadFactor()) {
            return DECREASETABLE; // the load factor is below the upper load factor, need to decrease table.
        }
        return 0;
    }
}
