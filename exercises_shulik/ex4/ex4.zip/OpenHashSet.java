
import java.util.LinkedList;

/**
 * A subclass of simpleHashSet which uses open-hashing which is implemented using linked-lists.
 */
public class OpenHashSet extends SimpleHashSet {

    /**
     * An array of instances of Facade class.
     */
    private innerFacade[] table;

    /**
     * Constructs a new, empty table with the specified load factors, and the default inital
     * capacity
     * @param upperLoadFactor - The upper load factor of the hash table.
     * @param lowerLoadFactor - the lower load factor of the hash table.
     */
    public OpenHashSet(float upperLoadFactor, float lowerLoadFactor) {
        super(upperLoadFactor, lowerLoadFactor);
        this.table = new innerFacade[this.tableCapacity];
        for (int i = 0; i < this.tableCapacity; i++) { //creates and array of LinkedLists wrapped by a facade.
            this.table[i] = new innerFacade();
        }
    }

    /**
     * A default constructor, Constructs a new, empty table with defaulted values from
     * the super's defaulted constructor.
     */
    public OpenHashSet() {
        super();
        this.table = new innerFacade[this.tableCapacity];
        for(int i = 0; i < this.tableCapacity; i ++){
            this.table[i] = new innerFacade();
        }
    }

    /**
     * Data constructor - builds the hash set by adding the elements one by one. duplicate values are ignored.
     * The new table has the default values of initial capacity, upper load factor and lower
     * load factor.
     * @param data - Values to add to the set.
     */
    public OpenHashSet(java.lang.String[] data) {
        super();
        this.table = new innerFacade[INITIAL_CAPACITY];
        for(int j = 0; j < this.table.length; j ++){
            this.table[j] = new innerFacade();
        }
        for (String tempItem : data) { // adds all items on the given data.
            this.add(tempItem);
        }

    }

    /**
     * overrides the abstract clamp method. Clamps the given index into the tables index range.
     * @param index - the index before clamping, the hashcode of the item to insert.
     * @return - The clamped index after being edited.
     */
    @Override
    public int clamp(int index) {
        return index & (this.tableCapacity - 1);
    }

    /**
     * Add a specified element to the set if its not already in it.
     * @param newValue - New value to add to the set
     * @return - False if newValue already exists in the set, True otherwise.
     */
    public boolean add(java.lang.String newValue) {
        if (this.contains(newValue)) { //set already contains item.
            return false;
        }
        if (this.checkLoadFactor(INCREASETABLE) == INCREASETABLE) {
            //checks if a resize is needed before addition to avoid crossing the upper load factor.
            this.resizeTable(INCREASETABLE);
        }
        int clampIndex = this.clamp(newValue.hashCode());
        //System.out.println("i fail after " + this.counter + 1+ " runs");
        this.table[clampIndex].add(newValue);
        this.tableSize++;
        return true;
    }

    /**
     * Look for a specified value in the set.
     * @param searchVal - Value to search for.
     * @return - True if searchVal is found in the set.
     */
    public boolean contains(java.lang.String searchVal) {
        int clampedIndex = this.clamp(searchVal.hashCode());
        if(this.table[clampedIndex].size() == 0){
            return false;
        }
        if(this.table[clampedIndex].contains(searchVal)){
            return true;
        }
        return false;
    }

    /**
     * Remove the input element from the set.
     * @param toDelete - Value to delete.
     * @return - True if toDelete is found and deleted.
     */
    public boolean delete(java.lang.String toDelete) {
        if (!this.contains(toDelete)) {
            return false;
        }
        int itemIndex = this.clamp(toDelete.hashCode()); // gets the index for quick access.
        this.table[itemIndex].delete(toDelete);
        this.tableSize--;
        if (this.checkLoadFactor(DECREASETABLE) == DECREASETABLE && this.tableCapacity != 1) {
            this.resizeTable(DECREASETABLE); // calls resize method with decrease constant.
        }
        return true;
    }

    /**
     * @return - returns the amount of elements the set contains.
     */
    public int size() {
        return this.tableSize;
    }

    /**
     * @return - The capacity in class SimpleHashSet.
     */
    public int capacity() {
        return this.tableCapacity;
    }


    /**
     * Subclass which inherits CollectionFacadeSet which allows access to protected data members.
     */
    private class innerFacade extends CollectionFacadeSet {
        /**
         * Constructor for the class, Creates by default a wrapper for Linked Lists.
         */
        private innerFacade() {
            super(new LinkedList<String>());
        }
    }

    /**
     * This method resizes the table according to the value it is given. it decreases or increases the table
     * depending on the need.
     * @param changeVal - An informative value which indicates if the table need increasing or decreasing.
     *                  changeVal = 1 means and increase is needed, changeVal = -1 implies the contrary.
     */
    private void resizeTable(int changeVal) {
        int NEWTABLESIZE = 0;
        if (changeVal == INCREASETABLE) {
            innerFacade[] tempTable = this.table.clone();
            this.table = new innerFacade[tempTable.length * 2]; //creates a new array, double the size.
            this.tableSize = NEWTABLESIZE;
            this.tableCapacity = this.table.length; // updates table capacity.
            for(int i = 0; i < this.table.length; i++){
                this.table[i] = new innerFacade();
            }
            for (innerFacade inList : tempTable) {
                for (String item : inList.collection) { //iterates over the Linked list, re-adding all items.
                    this.add(item);
                }
            }
        }
        if (changeVal == DECREASETABLE) {
            innerFacade[] tempTable = this.table.clone();
            this.table = new innerFacade[tempTable.length / 2];//creates a new array, half the size.
            this.tableSize = NEWTABLESIZE;
            this.tableCapacity = this.table.length;
            for (int k = 0; k < this.table.length; k++) {
                this.table[k] = new innerFacade(); //creates new table.
            }
            for(innerFacade innerList : tempTable){
                for (String item : innerList.collection) {
                    //iterates over the Linked list, re-adding all items.
                    this.add(item);
                }
            }
        }
    }
}