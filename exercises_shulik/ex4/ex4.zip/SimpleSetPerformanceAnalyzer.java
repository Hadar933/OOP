import java.util.ArrayList;

public class SimpleSetPerformanceAnalyzer {
    private static final int DATA1UPPERBOUND = 4;
    private static final int DATA2LOWERBOUND = 5;
    private static final String CALCULATEMSG = "Calculating Running time of ";
    private static final String CONTAINMSG = "contain method for ";
    private static final String RESULTEMSG = "Running time of contain method for ";
    private static final String WARMUPMSG = "This run only serves as warmup and is to be ignored";
    private static final String WARMUPOVERMSG = " Warmup is done real running time test to follow this";

    /**
     * An array where each index holds a different data structure which implements the SimpleSet interface,
     * first five cells (0 - 4) for data1.txt last five (5 - 9)contain data2.txt.
     */
    private SimpleSet[] collectionArray = new SimpleSet[10];

    /**
     * Two arrays which contain the values we would like to check against our data files, one for each file.
     * allows easily adding values.
     */
    private ArrayList<String> data1TestValues;
    private ArrayList<String> data2TestValues;

    /**
     * Constructor for this class, creates the test value lists and inserts an instance of CollectionFacadeSet
     * into each cell, each one wrapping a different collection.
     */
    public SimpleSetPerformanceAnalyzer() {
        this.data1TestValues = new ArrayList<>();
        this.data2TestValues = new ArrayList<>();
        this.collectionArray[0] = new OpenHashSet();
        this.collectionArray[1] = new ClosedHashSet();
        this.collectionArray[2] = new CollectionFacadeSet(new java.util.HashSet<>());
        this.collectionArray[3] = new CollectionFacadeSet(new java.util.LinkedList<>());
        this.collectionArray[4] = new CollectionFacadeSet(new java.util.TreeSet<>());
        this.collectionArray[5] = new OpenHashSet();
        this.collectionArray[6] = new ClosedHashSet();
        this.collectionArray[7] = new CollectionFacadeSet(new java.util.HashSet<>());
        this.collectionArray[8] = new CollectionFacadeSet(new java.util.LinkedList<>());
        this.collectionArray[9] = new CollectionFacadeSet(new java.util.TreeSet<>());
    }

    /**
     * This method add the given data to the chosen data-structure/s. allows to switch easily between adding
     * to a few data structures or just one.
     *
     * @param startIndex  - The index to start running from.
     * @param finishIndex - The index to stop - notice it is including in the running so data will be added.
     * @param dataName    - The name of the file to read from.
     */
    private void addData(int startIndex, int finishIndex, String dataName) {
        int PERCENTAGE = 100;
        double nanoToMili = 1000000;
        String[] dataFile = Ex4Utils.file2array(dataName);
        for (int i = startIndex; i <= finishIndex; i++) {
            System.out.println(CALCULATEMSG + this.collectionArray[i].toString() + " " + dataName);
            long timeBefore = System.nanoTime();
            for (int k = 0; k < dataFile.length; k++) {
                this.collectionArray[i].add(dataFile[k]);
                if (k % 10000 == 0) {
                    System.out.println((double) k / (double) dataFile.length * PERCENTAGE + "% iterated over");
                }
            }
            long difference = System.nanoTime() - timeBefore;
            double newDiff = (double) difference / nanoToMili;
            System.out.println("Time for " + this.collectionArray[i].toString() + " is" + " " + newDiff);
        }
    }

    /**
     * This method calculates the running time of "conatain" method for a chosen data structure.
     *
     * @param searchVal - The value to search for.
     * @param startIndex - allows choice of which data structures to start testing testing form.
     * @param finishIndex - allows choice of up to which data structure to test.
     */
    private void checkContains(String searchVal, int startIndex, int finishIndex) {
        final int NUMBEROFRUNS = 70000;
        final int LINKEDLISTITERATIONS = 7000;
        for(int i = startIndex; i <= finishIndex; i++){
            if(i != 3 && i !=8){
                System.out.println(CALCULATEMSG + CONTAINMSG + searchVal +
                        " " + this.collectionArray[i].toString());
                long timeBefore = System.nanoTime();
                for(int k = 0; k < NUMBEROFRUNS; k ++){
                    this.collectionArray[i].contains(searchVal);
                }
                long difference = System.nanoTime() - timeBefore;
                double runTime = (double)difference/NUMBEROFRUNS;
                System.out.println(RESULTEMSG + searchVal + " " +
                        this.collectionArray[i].toString() + " is " + runTime);
            }
            else{
                System.out.println(CALCULATEMSG + searchVal + " " +
                        CONTAINMSG + " " + this.collectionArray[i].toString());
                long timeBefore = System.nanoTime();
                for(int j = 0; j < LINKEDLISTITERATIONS; j++) {
                    this.collectionArray[i].contains(searchVal);
                }
                long difference = System.nanoTime() - timeBefore;
                double runTime = (double)difference/NUMBEROFRUNS;
                System.out.println(RESULTEMSG + searchVal + " " +
                        this.collectionArray[i].toString() + " is " + runTime);
            }
        }
    }

    /**
     * This method contains all runtime tests which are run over Collections containing data1.
     */
    private void data1Test(){
        System.out.println("Data1 runtime tests:");
        for(String item: this.data1TestValues){
            System.out.println(WARMUPMSG);
            for(int k = 0; k <= DATA1UPPERBOUND; k++ ){
                this.checkContains(item, k, k); // performs warm up for each of the sets.
            }
            System.out.println(WARMUPOVERMSG);
            System.out.println(" ");
            // Calculates running time for "hi" input after JVM warmup over file data1.
            for(int k = 0; k <= DATA1UPPERBOUND; k++ ){
                this.checkContains(item, k, k);//checks real running time for each set.
            }
        }
        System.out.println(" ");
    }
    /**
     * This method contains all running time tests which are run over Collections containing data2.
     */
    private void data2Test() {
        System.out.println("Data2 runtime tests:");
        for (String searchVal : this.data2TestValues) {
            System.out.println(WARMUPMSG); //performs warmup for input "hi" in over file data2
            for (int i = DATA2LOWERBOUND; i < this.collectionArray.length; i++) {
                this.checkContains(searchVal, i, i);
            }
            System.out.println(WARMUPOVERMSG);
            System.out.println(" ");
            //performs real time running test for input "hi" over file data2.
            for (int i = DATA2LOWERBOUND; i < this.collectionArray.length; i++) {
                this.checkContains(searchVal, i, i);
            }
            System.out.println(" ");
        }
    }

    public static void main(String[] args) {
        //initialization of a new instance
        SimpleSetPerformanceAnalyzer timeAnalyzer = new SimpleSetPerformanceAnalyzer();
        System.out.println("Analyzer instance created");
        System.out.println(" ");

        //Add values to check runtime with.
        timeAnalyzer.data1TestValues.add("hi");
        timeAnalyzer.data1TestValues.add("-13170890158");
        timeAnalyzer.data2TestValues.add("23");
        timeAnalyzer.data2TestValues.add("hi");

        //Running time for addition of data1 and data2
        timeAnalyzer.addData(0, 4, "data1.txt");
        System.out.println(timeAnalyzer.collectionArray[1].size());
        System.out.println("Data1 addition is done");
        System.out.println(" ");
        timeAnalyzer.addData(5, 9, "data2.txt");
        System.out.println("Data2 addition is done");
        System.out.println(" ");

        //Running time for contain method for different inputs
        timeAnalyzer.data1Test();
        System.out.println("Data1 contain method tests finished");
        System.out.println(" ");
        timeAnalyzer.data2Test();
        System.out.println(" ");
        System.out.println("Data2 contain method tests finished");
    }
}


