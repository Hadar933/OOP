package GeneralExceptions;

public abstract class TypeTwoException extends Exception{

    @Override
    public String toString() {
        return "either a bad subsection name was given or bad format of the Command File";
    }
}
