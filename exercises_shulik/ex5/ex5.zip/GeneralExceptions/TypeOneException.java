package GeneralExceptions;

import Filter.FilterExceptions;

public abstract class TypeOneException extends Exception{

    public static class argAmountException extends FilterExceptions {
        public argAmountException() {
            super();
        }
    }
}
