package GeneralExceptions;
import Filter.FilterExceptions;

public class BadSuffixException extends FilterExceptions {
    public BadSuffixException() {
        super();
    }
}
