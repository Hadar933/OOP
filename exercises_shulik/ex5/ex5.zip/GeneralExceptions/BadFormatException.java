package GeneralExceptions;

public class BadFormatException extends TypeTwoException {
    public BadFormatException() {
        super();
    }
}
