package Filter;

 class NegativeValException extends FilterExceptions {
     NegativeValException() {
        super();
    }
}
