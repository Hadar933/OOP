package Filter;

class BadFilterName extends FilterExceptions {
     BadFilterName() {
        super();
    }
}
