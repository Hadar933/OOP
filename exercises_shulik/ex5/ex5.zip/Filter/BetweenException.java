package Filter;

 class BetweenException extends FilterExceptions {
     BetweenException() {
        super();
    }
}
