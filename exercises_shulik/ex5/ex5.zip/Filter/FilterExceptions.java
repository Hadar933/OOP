package Filter;
import GeneralExceptions.TypeOneException;

public abstract class FilterExceptions extends TypeOneException {
    public FilterExceptions() {
        super();
    }
}
