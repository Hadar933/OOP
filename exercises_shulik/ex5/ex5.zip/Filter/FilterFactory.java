package Filter;

import java.io.File;

import GeneralExceptions.BadSuffixException;
import GeneralExceptions.TypeOneException;
import filesprocessing.ToolBox;


/**
 *A class which acts a factory for all types of filters, holds main method which acts as factory and helper
 * methods which check if all conditions apply.
 */
public class FilterFactory{
    private static final String NOTSUFFIX = "NOT";
    private static final String YESSUFFIX = "YES";
    private static final String NOSUFFIX = "NO";
    private static final int MINALLFILTER = 1;
    private static final int THREEINDEX = 3;
    private static final int BETWEENCONST = 4;
    private static final int STRSUFFIXLENGTH = 2;


    /**
     *A factory method used to create filters.
     * @param argArray - an array of arguments containing the needed data for each filter.
     * @return - a filter which fits the demands given.
     * @throws FilterExceptions - a general filter related exception.
     */
    public static Filter createFilter(String[] argArray) throws TypeOneException {

        if(argArray.length < MINALLFILTER){
            throw new TypeOneException.argAmountException();
        }
            switch (argArray[0]) {
                case "all":
                    return checkAll(argArray);
                case "greater_than":
                    return checkGreaterInt(Double.parseDouble(argArray[1]), argArray);
                case "smaller_than":
                    return checkSmallerInt(Double.parseDouble(argArray[1]), argArray);
                case "between":
                    return checkBetween(Double.parseDouble(argArray[1]),
                            Double.parseDouble(argArray[2]), argArray);
                case "file":
                    Filter tempFilter = file -> file.getName().equals(argArray[1]);
                    if(checkSuffix(argArray)){
                        return tempFilter;
                    }
                    return tempFilter.negate();
                case "contains":
                    Filter tempContainFilter = file -> file.getName().contains(argArray[1]);
                    if(checkSuffix(argArray)){
                        return tempContainFilter;
                    }
                    return tempContainFilter.negate();
                case "prefix":
                    Filter tempPreFilter = file -> file.getName().startsWith(argArray[1]);
                    if(checkSuffix(argArray)){
                        return tempPreFilter;
                    }
                    return tempPreFilter.negate();
                case "suffix":
                    Filter tempSufFilter = file -> file.getName().endsWith(argArray[1]);
                    if(checkSuffix(argArray)){
                        return tempSufFilter;
                    }
                    return tempSufFilter.negate();
                case "writable":
                    return checkWritable(argArray);
                case "executable":
                    return checkExecutable(argArray);
                case "hidden":
                    return checkHidden(argArray);
                default:
                    throw new BadFilterName();
            }
    }

    /**
     * @return - returns the defaulted filter.
     */
    public static Filter getDefault(){
        return file -> true;
    }

    /**
     * This method checks all conditions for "all" filter.
     * @param args - an array containing needed data.
     * @return - A filter which which returns either all files or none.
     * @throws BadSuffixException - an Exception which indicates there is something wrong with the given
     * suffix.
     */
    private static Filter checkAll(String[] args) throws BadSuffixException {
        Filter allFilter = file -> true;
        if(args.length == MINALLFILTER){
            return allFilter;
        }
        if(args[1] == null){
            return allFilter;
        }
        else if(args[1].equals(NOTSUFFIX)){
            return allFilter.negate();
        }
        throw new BadSuffixException();
    }

    /**
     * This method checks int input for size related input.
     * @param checkVal - The value to check.
     * @return - true if the value is legal and can be used, false otherwise.
     */
    private static boolean checkLegalInt(double checkVal){
        return !(checkVal >= 0);
    }

    /**
     * This method creates a Filter which filters according to file size, checks if all conditions are met
     * before creating the filters.
     * @param factorSize - The size of file to check against.
     * @return - returns a Filter which filters for all files greater/smaller than factorSize.
     * @throws NegativeValException - an Exception which indicates a negative input.
     */
    private static Filter checkGreaterInt(double factorSize, String[] args) throws TypeOneException {
        Filter tempFilter = file -> ToolBox.bytesTokBytes(file.length()) > factorSize;
        if(checkLegalInt(factorSize)){
            throw new NegativeValException();
        }
        else if(args.length >= THREEINDEX){
            if(args[2].equals(NOTSUFFIX)){
                return tempFilter.negate(); //casts to Filter from predicate.
            }
            else{ //illegal suffix input.
                throw new BadFilterName();
            }
        }
        return tempFilter;
    }

    /**
     * This method creates a Filter instance which filters according to file size.
     * @param upperFactor - the upper limit of file size to filter against.
     * @return - a Filter instance which filters either all files who's size is greater/smaller than
     * upperFactor depends on the given info.
     * @throws NegativeValException - an exception which indicates illegal negative input.
     */
    private static Filter checkSmallerInt(double upperFactor, String[] args) throws TypeOneException {
        Filter tempFilter = file -> ToolBox.bytesTokBytes(file.length()) < upperFactor;
        if(checkLegalInt(upperFactor)){
            throw new NegativeValException();
        }
        else if(args.length >= THREEINDEX ){
            if(args[2].equals(NOTSUFFIX)){
                return tempFilter.negate();
            }
            else{ //illegal suffix input
                throw new BadFilterName();
            }
        }
        return tempFilter;
    }

    /**
     * This method creates a filter which checks if all conditions are met before returning a filter which
     * returns all files between given size limits.
     * @param lowerFactor - The lower limit for file size.
     * @param upperFactor - the upper limit for a file size.
     * @return - A filter instance which filters all files who's size fits between the given limits or the
     * opposite. depends on the given data.
     * @throws NegativeValException - an exception which indicates illegal negative input.
     * @throws BetweenException - lower bound of between filter is greated than its upper bound.
     */
    private static Filter checkBetween(double lowerFactor, double upperFactor, String[] args)
            throws FilterExceptions {
        Filter tempFilter = file -> ToolBox.bytesTokBytes(file.length()) >= lowerFactor &&
                ToolBox.bytesTokBytes(file.length()) <= upperFactor;
        if (checkLegalInt(lowerFactor) || checkLegalInt(upperFactor)) {
            throw new NegativeValException();
        } else if (lowerFactor > upperFactor) {
            throw new BetweenException();
        }
        if(args.length == BETWEENCONST && args[3].equals(NOTSUFFIX)){
            return tempFilter.negate();
        }
        return tempFilter;
    }

    /**
     * This method check for if a NOT suffix exists for all String value Filters.
     * @param args - an array containing data.
     * @return - returns true if a suffix exists and is legal, false otherwise.
     * @throws BadSuffixException - an illegal suffix is given.
     */
    private static boolean checkSuffix(String[] args) throws BadSuffixException {
       if(args.length != THREEINDEX){
           return true;
       }
       else if(args[2].equals(NOTSUFFIX)){
           return false;
       }
       throw new BadSuffixException();
    }

    /**
     * This method checks if a suffix exists and is legal.
     * @param args - an array holding needed data.
     */
    private static void checkYesNoSuffix(String[] args) throws BadSuffixException {
        if(args.length < STRSUFFIXLENGTH ){ //no YES/NO suffix at all.
            throw new BadSuffixException();
        }
        if(!args[1].equals(NOSUFFIX) && !args[1].equals(YESSUFFIX)){
            throw new BadSuffixException(); //illegal suffix.
        }
    }

    /**
     *This method returns a Filter which filters all files which are writable or arent, depends on the given
     * input.
     * @param args - an array containing the info of the filter.
     * @return - returns an instance of filter.
     * @throws BadSuffixException - Indicates the filter has a bad suffix.
     */
    private static Filter checkWritable(String[] args) throws BadSuffixException {
        checkYesNoSuffix(args); //check if YES/NO suffix exists and is legal.
        Filter tempFilter = File::canWrite;
        if(args.length == THREEINDEX){ //check if a NOT suffix was given.
            if(!args[2].equals(NOTSUFFIX)){
                throw new BadSuffixException(); //illegal suffix, throw error.
            }
            else if(args[1].equals(YESSUFFIX) ){ //NOT suffix over YES suffix means NO;
                tempFilter = tempFilter.negate();
            }
        }
        if(args[1].equals(NOSUFFIX)){
            tempFilter = tempFilter.negate();
        }
        return tempFilter; //the only unchecked scenario is #NOT suffix on NO VALUE which is just the filter.
    }

    /**
     * this method creates a Filter which returns all files which are executable or all files which aren't
     * depends on the filter info.
     * @param args - an array containing the info for the filter.
     * @return - a lambda expression which acts as a filter.
     * @throws BadSuffixException - Indicates the filter has a bad suffix.
     */
    private static Filter checkExecutable(String[] args) throws BadSuffixException {
        checkYesNoSuffix(args);
        Filter tempFilter = File::canExecute;
        if(args.length == THREEINDEX){ //suffix exists.
             if(!args[2].equals(NOTSUFFIX)){
                 throw new BadSuffixException();//illegal suffix was given.
             }
             if(args[1].equals(YESSUFFIX) ){//
                tempFilter = tempFilter.negate();
             }
        }
        if(args[1].equals(NOSUFFIX)){
            tempFilter = tempFilter.negate();
        }
        return tempFilter;//the only unchecked scenario is #NOT suffix on NO VALUE which is just the filter.
    }

    /**
     * This method creates a filter according to given data.
     * @param args - an array containing the data which defines the filter.
     * @return - a lambda expression which acts as a filter.
     * @throws BadSuffixException - Indicates the filter has a bad suffix.
     */
    private static Filter checkHidden(String[] args) throws BadSuffixException {
        checkYesNoSuffix(args);
        Filter tempFilter = File::isHidden;
        if(args.length == THREEINDEX) { //some suffix exists.
            if (!args[2].equals(NOTSUFFIX)) { //illegal suffix given.
                throw new BadSuffixException();
            }
            if (args[1].equals(YESSUFFIX)) { //get all unhidden files.
                tempFilter = tempFilter.negate();
            }
        }
        if(args[1].equals(NOSUFFIX)){
            tempFilter = tempFilter.negate();
        }
        return tempFilter;//the only unchecked scenario is #NOT suffix on NO VALUE which is just the filter.
    }
}
