package Filter;

import java.util.function.Predicate;
import java.io.File;

@FunctionalInterface
public interface Filter extends Predicate<File> {

    /**
     *Declares the only abstract method of this functional interface, to be implemented by each filter.
     * @param file - The file to test.
     */
    @Override
    boolean test(File file);

    /**
     *Negates the test method.
     * @return -  returns the opposite logical lambda expression of the given test.
     */
    @Override
    default Filter negate() {
        return file -> !test(file);
    }
}

