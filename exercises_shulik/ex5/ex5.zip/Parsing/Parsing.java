package Parsing;

import Filter.*;
import GeneralExceptions.BadFormatException;
import GeneralExceptions.TypeOneException;
import GeneralExceptions.TypeTwoException;
import Order.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Parsing {
    private final static String WARNINGMSG = "Warning in line ";
    private final static String FILTERSTR = "FILTER";
    private final static String ORDERSTR = "ORDER";
    private final static int ONEFACTOR = 1;
    private final static int DEFVAL = 0;
    /**
     * The main method of this class, parses through the file creating sections and dealing with exceptions.
     * @param fileName - Name of the file to parse through.
     * @return - returns an array of Section, each containing its own exceptions, Filter an Order.
     * @throws TypeTwoException - exceptions which cause termination of the program, sent to the main class
     * to be dealt with there.
     */
    public static Section[] parseFile(String fileName) throws TypeTwoException, IOException {
        ArrayList<Section> secArray = new ArrayList<Section>();
        int lineCounter = 0;
        String[] lineArray = getFileLines(fileName);
        if(lineArray.length == DEFVAL){
            return null;
        }
        if(checkFormat(lineArray, lineCounter) || !lineArray[lineCounter].equals(FILTERSTR)){
            throw new BadFormatException();
        }
        while (lineCounter < lineArray.length) {
            if(checkFormat(lineArray, lineCounter)){
                throw new BadFormatException();
            }
            String delimiter = "#"; //define delimiter for split method.
            /*input needed to create each section*/
            Filter tempFilter;
            Order tempOrder;
            String[] filterInfoArray;
            String[] orderInfoArray;
            ArrayList<String> exceptionArray = new ArrayList<>();
            lineCounter++;
            /*creates Filter*/
            try {
                filterInfoArray = lineArray[lineCounter].split(delimiter);
                tempFilter = FilterFactory.createFilter(filterInfoArray);
            } catch (TypeOneException e) {
                exceptionArray.add(WARNINGMSG + (lineCounter + ONEFACTOR));
                tempFilter = FilterFactory.getDefault(); //gets "all" filter.
            }
            lineCounter++;
            if (lineCounter + ONEFACTOR > lineArray.length ||!lineArray[lineCounter].equals(ORDERSTR)) {
                throw new BadFormatException();
            }
            //no Order description.
            if ((lineCounter + ONEFACTOR) == (lineArray.length) ||
                    lineArray[lineCounter + ONEFACTOR].equals(FILTERSTR)) {
                Section tempSection =
                        new Section(exceptionArray, tempFilter, OrderFactory.getDefaultOrder());
                secArray.add(tempSection);
                lineCounter++;
                continue;
            }
            lineCounter++;
            try {
                orderInfoArray = lineArray[lineCounter].split(delimiter);
                tempOrder = OrderFactory.createOrder(orderInfoArray);
            } catch (TypeOneException e) {
                exceptionArray.add(WARNINGMSG + (lineCounter + ONEFACTOR));
                tempOrder = OrderFactory.getDefaultOrder();
            }
            Section tempSection = new Section(exceptionArray, tempFilter, tempOrder);
            secArray.add(tempSection);
            lineCounter++;
        }

    Section[] finalArray = new Section[secArray.size()];
        secArray.toArray(finalArray);
        return finalArray;
        }


    /**
     * Helper method for the parsing method, iterates over a given file, returning all lines in the file in an
     * array where each cell holds one line.
     * @param fileName - the name of the file to iterate over.
     * @return - returns an array containing all line of the file.
     * @throws IOException - an exception which is file related, thrown all the way to main class.
     */
    private static String[] getFileLines(String fileName) throws IOException{
        // A list to hold the file's content
        List<String> fileContent = new ArrayList<>();

        // Reader object for reading the file
        BufferedReader reader;
            // Open a reader
            reader = new BufferedReader(new FileReader(fileName));

            // Read the first line
            String line = reader.readLine();

            // Go over the rest of the file
            while (line != null) {

                // Add the line to the list
                fileContent.add(line);

                // Read the next line
                line = reader.readLine();
            }
        String[] result = new String[fileContent.size()];
        fileContent.toArray(result);
        return result;
    }

    /**
     * checks the Command file contains the must have line for us to keep running. if it doesn't, theres no
     * no point to keep iterating and creating sections.
     * @param lineArray - an array where each cell contains a single line from the Command File.
     * @return - returns True if the format is legal, false otherwise.
     */
    private static boolean checkFormat(String[] lineArray, int startIndex){
        for(int i = startIndex; i <lineArray.length; i++){
            if(lineArray[i].equals(ORDERSTR)){
                return false;
            }
        }
        return true;
    }
}
