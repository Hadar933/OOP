package Parsing;

import java.util.ArrayList;
import Filter.*;
import Order.*;

public class Section {
    /**
     * an array which will hold the raised exceptions if any where found, filter and order.
     */
    private ArrayList<String> thrownExceptions;

    /**
     * Holds the filter given in this specific section.
     */
    private Filter myFilter;

    /**
     * Holds the Order in which we sort this section.
     */
    private Order myOrder;

     Section(ArrayList<String> myExceptions, Filter myFilter, Order myOrder) {
        this.thrownExceptions = myExceptions;
        this.myFilter = myFilter;
        this.myOrder = myOrder;
    }

    /**
     * @return - the filter data member of this instance.
     */
    public Filter getMyFilter(){
        return this.myFilter;
    }

    /**
     * @return - The Order data member of this instance.
     */
    public Order getMyOrder(){
        return this.myOrder;
    }

    /**
     * @return - an array containing all exceptions thrown while making this section.
     */
    public String[] getThrownExceptions(){
        String[] exceptionArray = new String[this.thrownExceptions.size()];
        this.thrownExceptions.toArray(exceptionArray);
        return exceptionArray;
    }


}
