package Order;

import java.util.Comparator;
import java.io.File;
import java.util.Objects;

@FunctionalInterface
public interface Order extends Comparator<File> {
    /**
     * declares a method which will be returned as the Order for the parsing class.
     * @param file1 - 1st file to compare.
     * @param file2 - 2nd file to compare.
     */
    @Override
    int compare(File file1, File file2);

    /**
     * this method returns the reverse order of the given compare method we are using.
     */
    @Override
    default Order reversed() {
        return (file1, file2) -> -this.compare(file1, file2);
    }

    /**
     * This method implements thenCompare method of Comparator interface which is used to deal with
     * situations when the first compare method came up short.
     * @param other - the new Order to compare against.
     * @return - returns a 2nd compare method to use.
     */
    default Order thenComparing(Order other) {
        Objects.requireNonNull(other);
        return (File c1, File c2) -> {
            int res = compare(c1, c2);
            return (res != 0) ? res : other.compare(c1, c2);
        };
    }
}
