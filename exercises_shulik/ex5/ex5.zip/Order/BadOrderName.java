package Order;
import GeneralExceptions.TypeOneException;

class BadOrderName extends TypeOneException {
     BadOrderName() {
        super();
    }
}
