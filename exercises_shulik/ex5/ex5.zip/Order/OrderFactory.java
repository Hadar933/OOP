package Order;

import java.io.File;
import GeneralExceptions.*;
import filesprocessing.ToolBox;

/**
 * a Factory class which creates different orders according to given data.
 */
public class OrderFactory  {
    private final static String REVERSESUFFIX = "REVERSE";
    private final static int INDEXFACTOR = 1;
    private final static int MINIAMLARGS = 1;
    private final static int NOPERIODS = 0;

    /**
     * The main method of the class, creates the Order instances.
     * @param argArray - an array containing the info about the needed Order.
     * @return - a lambda expression which defines the order of files.
     */
    public static Order createOrder(String[] argArray) throws TypeOneException {
        if(checkMinimalArgs(argArray) < MINIAMLARGS ){ // check minimal amount before even starting.
            throw new TypeOneException.argAmountException();
        }
        Order tempOrder;
        switch (argArray[0]){
            case "abs":
                tempOrder = checkAbs();
                break;
            case "type":
                tempOrder = checkType();
                break;
            case "size":
                tempOrder = checkSize();
                break;
            default:
                throw new BadOrderName(); //no Order is given, default is abs.
        }
        tempOrder = tempOrder.thenComparing(checkAbs()); //define thencompare.
        if(argArray.length == 2){ //check if the is a suffix
            if(!argArray[1].equals(REVERSESUFFIX)){ //check suffix legality.
                throw new BadSuffixException();
            }
            else{
                tempOrder = tempOrder.reversed();
            }
        }
        return tempOrder;
    }

    /**
     * @return - This method returns the defaulted order in case of exception.
     */
    public static Order getDefaultOrder(){
        return (file1, file2) -> file1.getAbsolutePath().compareTo(file2.getAbsolutePath());
    }

    /**
     * This method sums the amount of args and checks if the minimal amount is given.
     * @param argArray - an array containing info about the order.
     * @return - counter.
     */
    private static int checkMinimalArgs(String[] argArray){
        int counter = 0;
        for(String ignored: argArray){
            counter ++;
        }
        return counter;
    }

    /**
     * This method creates an Order instance which orders the files according to their absolute path.
     * @return - a lambda expressions which acts as
     */
    private static Order checkAbs(){
        return (file1, file2) -> file1.getAbsolutePath().compareTo(file2.getAbsolutePath());
    }

    /**
     * This method creates an Order according to given input.
     * @return - lambda expression which sorts according to file type.
     */
    private static Order checkType(){
        return (file1, file2) -> getFileType(file1).compareTo(getFileType(file2));
    }

    /**
     * This method creates a Size Order.
     * @return - lambda expression which sorts according to file size.
     */
    private static Order checkSize(){
        return (file1, file2) -> getFileSize(file1).compareTo(getFileSize(file2));
    }

    /**
     * This method get the type of a File.
     * @param file - the files type will be returned.
     * @return - string which is the type of the given file.
     */
    private static String getFileType(File file){
        String type = "";
        String name = file.getName();
        int amountOfPeriods = name.length() - name.replace(".", "").length();
        if(name.startsWith(".") && amountOfPeriods == INDEXFACTOR){
            return type;
        }
        else if(amountOfPeriods == NOPERIODS){
            return type;
        }
        if(file.exists()){
            String tempName = file.getName();
            type = tempName.substring(tempName.lastIndexOf(".") + INDEXFACTOR);
            //returns a substring from the last "." until the end of the String
        }
        return type;
    }

    /**
     * This method returns the size of the file in bytes.
     * @param file - input to check size of.
     * @return - a Long which is the given files size.
     */
    private static Double getFileSize(File file){
        return ToolBox.bytesTokBytes(file.length());
    }

}
