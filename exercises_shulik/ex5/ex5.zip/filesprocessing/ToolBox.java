package filesprocessing;

import Order.*;
import java.io.File;


public class ToolBox {
    private static final double KBFACTOR = 1024.0;
    private static final int ZEROINDEX = 0;
    private static final int ONEFACTOR = 1;

    /**
     * This method converts file size which is given in bytes to k-bytes.
     * @param byteVal - the size of the file in bytes.
     * @return - returns the size in k- bytes.
     */
    public static double bytesTokBytes(double byteVal){
        return (byteVal / KBFACTOR);
    }

    /**
     * The sorting method itself. receives indexes and breaks the array into smaller arrays which have already
     * been sorted. each time sorting a growing part of the original array.
     * @param fileArray - The array to sort.
     * @param order - the order to sort by.
     * @param left - index to sort from.
     * @param middle the middle which divides the two lists.
     * @param right - the index to sort to.
     */
    private static void merge(File[] fileArray, Order order, int left, int middle, int right){
        int arr1Length = middle - left + ONEFACTOR;
        int arr2Length = right - middle;

        /*create sub arrays to be merged*/
        File[] L = new File[arr1Length];
        File[] R = new File[arr2Length];

        /*insert data to new temp arrays*/
        for(int i = ZEROINDEX; i < arr1Length; i++){
            L[i] = fileArray[left + i];
        }
        for(int j = ZEROINDEX; j < arr2Length; j++){
            R[j] = fileArray[middle + ONEFACTOR + j];
        }

        /*Merge the subarrays*/
        int i = ZEROINDEX, j = ZEROINDEX;
        int k = left;
        while(i < arr1Length && j < arr2Length){
            if(order.compare(L[i], R[j]) < ZEROINDEX){
                fileArray[k] = L[i];
                i++;
            }
            else{
                fileArray[k] = R[j];
                j++;
            }
            k++;
        }
        /*Copy the remaining L[] elements if they exist*/
        while(i < arr1Length){
            fileArray[k] = L[i];
            i++;
            k++;
        }
        /*Copy the remaining R[] elements if they exist*/
        while(j < arr2Length){
            fileArray[k] = R[j];
            j++;
            k++;
        }
    }

    /**
     * a recursive sorting algorithm, this version of merge sort is in-place unlike the popular version.
     * @param fileArray - The array to sort.
     * @param left - index to start sorting from.
     * @param right - index to sort to.
     * @param order - the order to sort by.
     */
     static void mergeSort(File[] fileArray, int left, int right, Order order){
        if(left < right){
            int middle = (left + right) / 2; //find middle point of the array
            mergeSort(fileArray, left, middle, order); // sort both halves.
            mergeSort(fileArray, middle + ONEFACTOR, right, order);
            merge(fileArray, order, left, middle, right); //merge the sorted values.
        }
    }

}

