package filesprocessing;

import GeneralExceptions.*;
import Parsing.*;
import Filter.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;


import Order.*;

public class DirectoryProcessor {


    public static void main(String[] args) {
        int ARGAMOUNT = 2;
        int DEFAULTVAL = 0;
        int SIZEFACTOR = 1;
        try {
            if (args.length != ARGAMOUNT) {
                throw new BadFormatException();
            }
            File srcDir = new File(args[0]);
            File[] fileArray = srcDir.listFiles(); //an array of all files in the source directory.
            Section[] secArray = Parsing.parseFile(args[1]); //get an array of Sections for Command File.
            if(fileArray == null | secArray == null){ //checks that arrays exist.
                return;
            }
            if(fileArray.length == DEFAULTVAL || secArray.length == DEFAULTVAL){ //checks that input was given
                return;
            }
            for(Section tempSection: secArray){
                ArrayList<File> fileList = new ArrayList<>();
                Filter tempFilter = tempSection.getMyFilter();
                Order tempOrder = tempSection.getMyOrder();
                for(File file : fileArray){
                    if(file.isFile() && tempFilter.test(file)){ //filters all files.
                        fileList.add(file);
                    }
                }
                File[] finalArray = new File[fileList.size()];
                fileList.toArray(finalArray);
                /*Sorts the list according to the given order.*/
                ToolBox.mergeSort(finalArray, DEFAULTVAL, finalArray.length - SIZEFACTOR, tempOrder);
                /*print all type one exceptions of this section*/
                for(String warning : tempSection.getThrownExceptions()){
                    System.err.println(warning);
                }
                for(File file : finalArray){
                    System.out.println(file.getName());
                }
            }
        }
        catch(IOException | TypeTwoException e){
            System.err.println("ERROR: " + e);
        }
    }

}
